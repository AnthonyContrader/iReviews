export enum Usertype {
    ADMIN,
    USER
}
